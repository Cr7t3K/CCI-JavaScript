document.addEventListener('DOMContentLoaded', () => {
    // Ci-dessous le script JS pour gérer la génération de la grille et le placement du coffre, des rochers et du trésor.





});
